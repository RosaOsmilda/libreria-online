-- Tabla contacto requerida por el proyecto
CREATE TABLE IF NOT EXISTS `contacto` (
  `id`          INT(11)       NOT NULL AUTO_INCREMENT,
  `fecha`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `correo`      VARCHAR(100)  NOT NULL,
  `nombre`      VARCHAR(80)   NOT NULL,
  `asunto`      VARCHAR(150)  NOT NULL,
  `comentario`  TEXT          NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
