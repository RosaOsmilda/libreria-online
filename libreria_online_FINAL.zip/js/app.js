/* =====================================================
   LIBRERÍA ONLINE — JavaScript Principal
   ===================================================== */

document.addEventListener('DOMContentLoaded', function () {

    /* ---- Buscador en tiempo real (libros) ---- */
    const inputBuscar = document.getElementById('buscar-libro');
    if (inputBuscar) {
        inputBuscar.addEventListener('input', function () {
            const termino = this.value.toLowerCase().trim();
            const filas   = document.querySelectorAll('[data-fila-libro]');
            let visibles  = 0;

            filas.forEach(function (fila) {
                const texto = fila.dataset.filaLibro.toLowerCase();
                const mostrar = termino === '' || texto.includes(termino);
                fila.style.display = mostrar ? '' : 'none';
                if (mostrar) visibles++;
            });

            const contador = document.getElementById('contador-libros');
            if (contador) contador.textContent = visibles + ' libro(s) encontrado(s)';
        });
    }

    /* ---- Buscador en tiempo real (autores) ---- */
    const inputAutor = document.getElementById('buscar-autor');
    if (inputAutor) {
        inputAutor.addEventListener('input', function () {
            const termino = this.value.toLowerCase().trim();
            const filas   = document.querySelectorAll('[data-fila-autor]');
            let visibles  = 0;

            filas.forEach(function (fila) {
                const texto = fila.dataset.filaAutor.toLowerCase();
                const mostrar = termino === '' || texto.includes(termino);
                fila.style.display = mostrar ? '' : 'none';
                if (mostrar) visibles++;
            });

            const contador = document.getElementById('contador-autores');
            if (contador) contador.textContent = visibles + ' autor(es) encontrado(s)';
        });
    }

    /* ---- Navbar: sombra al hacer scroll ---- */
    const navbar = document.getElementById('navbar-principal');
    if (navbar) {
        window.addEventListener('scroll', function () {
            navbar.style.boxShadow = window.scrollY > 30
                ? '0 4px 20px rgba(0,0,0,.5)'
                : 'none';
        });
    }

    /* ---- Validación del formulario de contacto ---- */
    const formulario = document.getElementById('form-contacto');
    if (formulario) {
        formulario.addEventListener('submit', function (e) {
            const campos = formulario.querySelectorAll('[required]');
            let valido = true;

            campos.forEach(function (campo) {
                campo.classList.remove('is-invalid');
                if (!campo.value.trim()) {
                    campo.classList.add('is-invalid');
                    valido = false;
                }
            });

            // Validar formato de correo
            const correo = document.getElementById('correo');
            if (correo && correo.value.trim()) {
                const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!regex.test(correo.value)) {
                    correo.classList.add('is-invalid');
                    valido = false;
                }
            }

            if (!valido) {
                e.preventDefault();
                // Scroll al primer campo inválido
                const primero = formulario.querySelector('.is-invalid');
                if (primero) primero.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        });

        // Limpiar estado de error al escribir
        formulario.querySelectorAll('.form-control').forEach(function (campo) {
            campo.addEventListener('input', function () {
                this.classList.remove('is-invalid');
            });
        });
    }

    /* ---- Animar tarjetas al cargar ---- */
    const tarjetas = document.querySelectorAll('.libro-card, .autor-card');
    tarjetas.forEach(function (card, i) {
        card.style.animationDelay = (i * 0.05) + 's';
        card.classList.add('fade-up');
    });

    /* ---- Auto-cerrar alertas de éxito después de 5 s ---- */
    const alerta = document.querySelector('.alerta-exito');
    if (alerta) {
        setTimeout(function () {
            alerta.style.transition = 'opacity .5s';
            alerta.style.opacity = '0';
            setTimeout(function () { alerta.remove(); }, 500);
        }, 5000);
    }

});
