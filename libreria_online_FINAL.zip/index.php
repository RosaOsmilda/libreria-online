<?php
$titulo_pagina = 'Inicio';
require_once 'includes/conexion.php';
require_once 'includes/header.php';

// Estadísticas generales
$pdo = conectar();

$total_libros  = $pdo->query("SELECT COUNT(*) FROM titulos")->fetchColumn();
$total_autores = $pdo->query("SELECT COUNT(*) FROM autores")->fetchColumn();
$total_tipos   = $pdo->query("SELECT COUNT(DISTINCT tipo) FROM titulos")->fetchColumn();

// Últimos 6 libros añadidos (por fecha de publicación)
$stmt = $pdo->query(
    "SELECT t.id_titulo, t.titulo, t.tipo, t.precio, t.total_ventas,
            GROUP_CONCAT(CONCAT(a.nombre, ' ', a.apellido) SEPARATOR ', ') AS autores
     FROM titulos t
     LEFT JOIN titulo_autor ta ON t.id_titulo = ta.id_titulo
     LEFT JOIN autores a        ON ta.id_autor  = a.id_autor
     GROUP BY t.id_titulo
     ORDER BY t.fecha_pub DESC
     LIMIT 6"
);
$ultimos_libros = $stmt->fetchAll();
?>

<!-- ===== HERO ===== -->
<section class="hero">
    <div class="container position-relative">
        <span class="hero-pretitle fade-up">Bienvenido a</span>
        <h1 class="hero-title fade-up fade-up-delay-1">
            Tu <em>Librería</em> Online
        </h1>
        <p class="hero-subtitle fade-up fade-up-delay-2">
            Explora nuestro catálogo de libros, conoce a los autores y encuentra
            tu próxima lectura favorita.
        </p>

        <!-- Estadísticas rápidas -->
        <div class="hero-badges fade-up fade-up-delay-3">
            <span class="badge-stat"><i class="bi bi-journals me-1"></i><?= $total_libros ?> Libros disponibles</span>
            <span class="badge-stat"><i class="bi bi-people me-1"></i><?= $total_autores ?> Autores</span>
            <span class="badge-stat"><i class="bi bi-tags me-1"></i><?= $total_tipos ?> Categorías</span>
        </div>

        <!-- Botones de acción -->
        <div class="d-flex justify-content-center gap-3 flex-wrap fade-up fade-up-delay-3">
            <a href="libros.php" class="btn btn-dorado">
                <i class="bi bi-journals me-2"></i>Ver Catálogo
            </a>
            <a href="autores.php" class="btn btn-contorno">
                <i class="bi bi-people me-2"></i>Ver Autores
            </a>
        </div>
    </div>
</section>

<!-- ===== ÚLTIMAS INCORPORACIONES ===== -->
<section class="seccion">
    <div class="container">
        <h2 class="seccion-titulo">Últimas Incorporaciones</h2>
        <hr class="seccion-linea">

        <div class="row g-4">
            <?php foreach ($ultimos_libros as $libro): ?>
            <div class="col-sm-6 col-lg-4">
                <div class="libro-card">
                    <div class="libro-icono">
                        <i class="bi bi-book"></i>
                    </div>
                    <span class="libro-tipo"><?= htmlspecialchars($libro['tipo']) ?></span>
                    <h3 class="libro-titulo"><?= htmlspecialchars($libro['titulo']) ?></h3>

                    <?php if ($libro['autores']): ?>
                    <p class="libro-meta">
                        <i class="bi bi-person"></i>
                        <?= htmlspecialchars($libro['autores']) ?>
                    </p>
                    <?php endif; ?>

                    <?php if ($libro['total_ventas']): ?>
                    <p class="libro-meta">
                        <i class="bi bi-bar-chart"></i>
                        <?= number_format($libro['total_ventas']) ?> ventas
                    </p>
                    <?php endif; ?>

                    <div class="libro-precio">
                        <?php if ($libro['precio']): ?>
                            $<?= number_format($libro['precio'], 2) ?> USD
                        <?php else: ?>
                            <span style="color:var(--color-texto-suave);font-size:.85rem;">Precio no disponible</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <div class="text-center mt-5">
            <a href="libros.php" class="btn btn-dorado">
                <i class="bi bi-grid me-2"></i>Ver Todos los Libros
            </a>
        </div>
    </div>
</section>

<!-- ===== SECCIÓN DE CATEGORÍAS ===== -->
<section class="seccion" style="background: var(--color-medio);">
    <div class="container">
        <h2 class="seccion-titulo">Categorías</h2>
        <hr class="seccion-linea">

        <?php
        $categorias = $pdo->query(
            "SELECT tipo, COUNT(*) AS cantidad FROM titulos GROUP BY tipo ORDER BY cantidad DESC"
        )->fetchAll();
        ?>

        <div class="row g-3">
            <?php foreach ($categorias as $cat): ?>
            <div class="col-6 col-md-4 col-lg-3">
                <div class="libro-card text-center py-3">
                    <div class="mb-2" style="font-size:2rem;color:var(--color-acento);">
                        <i class="bi bi-bookmark-star"></i>
                    </div>
                    <div class="libro-tipo"><?= htmlspecialchars($cat['tipo']) ?></div>
                    <p class="mt-2 mb-0" style="font-size:.85rem;color:var(--color-texto-suave);">
                        <?= $cat['cantidad'] ?> título(s)
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
