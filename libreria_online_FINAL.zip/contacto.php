<?php
$titulo_pagina = 'Contacto';
require_once 'includes/conexion.php';

// Variables de estado
$mensaje_exito = '';
$mensaje_error = '';
$errores       = [];

// ===== PROCESAR FORMULARIO (POST) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Obtener y limpiar datos
    $nombre     = trim($_POST['nombre']     ?? '');
    $correo     = trim($_POST['correo']     ?? '');
    $asunto     = trim($_POST['asunto']     ?? '');
    $comentario = trim($_POST['comentario'] ?? '');

    // Validaciones
    if (empty($nombre)) {
        $errores[] = 'El nombre es obligatorio.';
    }

    if (empty($correo)) {
        $errores[] = 'El correo electrónico es obligatorio.';
    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores[] = 'El correo electrónico no tiene un formato válido.';
    }

    if (empty($asunto)) {
        $errores[] = 'El asunto es obligatorio.';
    }

    if (empty($comentario)) {
        $errores[] = 'El comentario es obligatorio.';
    }

    // Si no hay errores, insertar en BD
    if (empty($errores)) {
        try {
            $pdo = conectar();

            // Crear tabla si no existe (primer uso)
            $pdo->exec(
                "CREATE TABLE IF NOT EXISTS `contacto` (
                    `id`          INT(11)       NOT NULL AUTO_INCREMENT,
                    `fecha`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `correo`      VARCHAR(100)  NOT NULL,
                    `nombre`      VARCHAR(80)   NOT NULL,
                    `asunto`      VARCHAR(150)  NOT NULL,
                    `comentario`  TEXT          NOT NULL,
                    PRIMARY KEY (`id`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
            );

            // Insertar con PDO (prepared statement)
            $stmt = $pdo->prepare(
                "INSERT INTO contacto (fecha, correo, nombre, asunto, comentario)
                 VALUES (NOW(), :correo, :nombre, :asunto, :comentario)"
            );

            $stmt->execute([
                ':correo'     => $correo,
                ':nombre'     => $nombre,
                ':asunto'     => $asunto,
                ':comentario' => $comentario,
            ]);

            $mensaje_exito = '¡Mensaje enviado correctamente! Nos pondremos en contacto contigo pronto.';

            // Limpiar campos tras éxito
            $nombre = $correo = $asunto = $comentario = '';

        } catch (PDOException $e) {
            $mensaje_error = 'Error al guardar el mensaje: ' . htmlspecialchars($e->getMessage());
        }
    }
}

require_once 'includes/header.php';
?>

<!-- ===== CABECERA ===== -->
<section class="hero" style="padding:60px 0 50px;">
    <div class="container position-relative">
        <span class="hero-pretitle">Estamos para ayudarte</span>
        <h1 class="hero-title" style="font-size:clamp(2rem,4vw,3rem);">
            <i class="bi bi-envelope me-2 text-accent"></i>Contáctanos
        </h1>
        <p class="hero-subtitle">
            ¿Tienes alguna pregunta o sugerencia? Completa el formulario y te responderemos a la brevedad.
        </p>
    </div>
</section>

<!-- ===== FORMULARIO + INFO ===== -->
<section class="seccion">
    <div class="container">
        <div class="row g-5">

            <!-- ---- Formulario ---- -->
            <div class="col-lg-8">

                <?php if ($mensaje_exito): ?>
                <div class="alerta-exito mb-4">
                    <i class="bi bi-check-circle-fill fs-5"></i>
                    <?= htmlspecialchars($mensaje_exito) ?>
                </div>
                <?php endif; ?>

                <?php if ($mensaje_error): ?>
                <div class="alerta-error mb-4">
                    <i class="bi bi-x-circle-fill fs-5"></i>
                    <?= $mensaje_error ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($errores)): ?>
                <div class="alerta-error mb-4">
                    <div>
                        <i class="bi bi-exclamation-triangle-fill fs-5 me-2"></i>
                        <strong>Por favor corrige los siguientes errores:</strong>
                        <ul class="mb-0 mt-2 ps-3">
                            <?php foreach ($errores as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <?php endif; ?>

                <div class="form-panel">
                    <h2 class="seccion-titulo" style="font-size:1.5rem;margin-bottom:.5rem;">
                        Formulario de Contacto
                    </h2>
                    <hr class="seccion-linea">

                    <form id="form-contacto" method="POST" action="contacto.php" novalidate>

                        <!-- Nombre -->
                        <div class="mb-4">
                            <label for="nombre" class="form-label">
                                <i class="bi bi-person me-1"></i>Nombre Completo <span style="color:#f87171;">*</span>
                            </label>
                            <input type="text"
                                   id="nombre"
                                   name="nombre"
                                   class="form-control"
                                   placeholder="Tu nombre completo"
                                   value="<?= htmlspecialchars($nombre ?? '') ?>"
                                   required>
                        </div>

                        <!-- Correo -->
                        <div class="mb-4">
                            <label for="correo" class="form-label">
                                <i class="bi bi-envelope me-1"></i>Correo Electrónico <span style="color:#f87171;">*</span>
                            </label>
                            <input type="email"
                                   id="correo"
                                   name="correo"
                                   class="form-control"
                                   placeholder="tu@correo.com"
                                   value="<?= htmlspecialchars($correo ?? '') ?>"
                                   required>
                        </div>

                        <!-- Asunto -->
                        <div class="mb-4">
                            <label for="asunto" class="form-label">
                                <i class="bi bi-chat-square-text me-1"></i>Asunto <span style="color:#f87171;">*</span>
                            </label>
                            <input type="text"
                                   id="asunto"
                                   name="asunto"
                                   class="form-control"
                                   placeholder="Motivo de tu mensaje"
                                   value="<?= htmlspecialchars($asunto ?? '') ?>"
                                   required>
                        </div>

                        <!-- Comentario -->
                        <div class="mb-4">
                            <label for="comentario" class="form-label">
                                <i class="bi bi-pencil me-1"></i>Comentario / Mensaje <span style="color:#f87171;">*</span>
                            </label>
                            <textarea id="comentario"
                                      name="comentario"
                                      class="form-control"
                                      rows="6"
                                      placeholder="Escribe aquí tu mensaje…"
                                      required><?= htmlspecialchars($comentario ?? '') ?></textarea>
                        </div>

                        <!-- Nota de campos obligatorios -->
                        <p style="font-size:.78rem;color:var(--color-texto-suave);">
                            <span style="color:#f87171;">*</span> Campos obligatorios
                        </p>

                        <!-- Botón enviar -->
                        <button type="submit" class="btn btn-dorado w-100 py-3 mt-2">
                            <i class="bi bi-send me-2"></i>Enviar Mensaje
                        </button>

                    </form>
                </div><!-- /form-panel -->
            </div>

            <!-- ---- Información de contacto ---- -->
            <div class="col-lg-4">
                <h2 class="seccion-titulo" style="font-size:1.3rem;margin-bottom:.5rem;">
                    Información de Contacto
                </h2>
                <hr class="seccion-linea">

                <div class="d-flex flex-column gap-3">

                    <div class="libro-card gap-3 flex-row align-items-start" style="display:flex !important;">
                        <div style="font-size:1.4rem;color:var(--color-acento);flex-shrink:0;">
                            <i class="bi bi-envelope-fill"></i>
                        </div>
                        <div>
                            <div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--color-texto-suave);margin-bottom:.2rem;">Correo</div>
                            <div style="font-size:.9rem;">info@libreriaonline.com</div>
                        </div>
                    </div>

                    <div class="libro-card gap-3 flex-row align-items-start" style="display:flex !important;">
                        <div style="font-size:1.4rem;color:var(--color-acento);flex-shrink:0;">
                            <i class="bi bi-telephone-fill"></i>
                        </div>
                        <div>
                            <div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--color-texto-suave);margin-bottom:.2rem;">Teléfono</div>
                            <div style="font-size:.9rem;">+1 (809) 000-0000</div>
                        </div>
                    </div>

                    <div class="libro-card gap-3 flex-row align-items-start" style="display:flex !important;">
                        <div style="font-size:1.4rem;color:var(--color-acento);flex-shrink:0;">
                            <i class="bi bi-geo-alt-fill"></i>
                        </div>
                        <div>
                            <div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--color-texto-suave);margin-bottom:.2rem;">Dirección</div>
                            <div style="font-size:.9rem;">Santo Domingo, República Dominicana</div>
                        </div>
                    </div>

                    <div class="libro-card gap-3 flex-row align-items-start" style="display:flex !important;">
                        <div style="font-size:1.4rem;color:var(--color-acento);flex-shrink:0;">
                            <i class="bi bi-clock-fill"></i>
                        </div>
                        <div>
                            <div style="font-size:.7rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--color-texto-suave);margin-bottom:.2rem;">Horario</div>
                            <div style="font-size:.9rem;">Lun – Vie: 8:00 AM – 6:00 PM</div>
                        </div>
                    </div>

                </div><!-- /gap -->

                <!-- Enlace rápido al catálogo -->
                <div class="mt-4 p-3" style="background:rgba(201,168,76,.08);border:1px solid rgba(201,168,76,.25);border-radius:var(--radio);">
                    <p style="font-size:.85rem;color:var(--color-texto-suave);margin-bottom:.75rem;">
                        ¿Buscas un título específico? Explora nuestro catálogo completo.
                    </p>
                    <a href="libros.php" class="btn btn-contorno btn-sm w-100">
                        <i class="bi bi-journals me-2"></i>Ver Catálogo
                    </a>
                </div>

            </div><!-- /col -->

        </div><!-- /row -->
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
