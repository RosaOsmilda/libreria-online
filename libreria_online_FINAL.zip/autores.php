<?php
$titulo_pagina = 'Autores';
require_once 'includes/conexion.php';
require_once 'includes/header.php';

$pdo = conectar();

// Obtener todos los autores con el número de libros que tienen
$stmt = $pdo->query(
    "SELECT a.id_autor,
            a.apellido,
            a.nombre,
            a.telefono,
            a.ciudad,
            a.estado,
            a.pais,
            a.cod_postal,
            COUNT(ta.id_titulo) AS total_libros
     FROM autores a
     LEFT JOIN titulo_autor ta ON a.id_autor = ta.id_autor
     GROUP BY a.id_autor
     ORDER BY a.apellido ASC, a.nombre ASC"
);

$autores       = $stmt->fetchAll();
$total_autores = count($autores);
?>

<!-- ===== CABECERA ===== -->
<section class="hero" style="padding:60px 0 50px;">
    <div class="container position-relative">
        <span class="hero-pretitle">Conoce a los creadores</span>
        <h1 class="hero-title" style="font-size:clamp(2rem,4vw,3rem);">
            <i class="bi bi-people me-2 text-accent"></i>Nuestros Autores
        </h1>
        <p class="hero-subtitle">
            <?= $total_autores ?> autores conforman nuestra red de talentos literarios.
        </p>
    </div>
</section>

<!-- ===== LISTADO DE AUTORES ===== -->
<section class="seccion">
    <div class="container">

        <!-- Barra de búsqueda + contador -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">

            <div class="contador-resultados">
                <i class="bi bi-list-ul"></i>
                <span id="contador-autores"><?= $total_autores ?> autor(es) encontrado(s)</span>
            </div>

            <div class="buscador-wrap">
                <i class="bi bi-search"></i>
                <input type="text"
                       id="buscar-autor"
                       class="form-control"
                       placeholder="Buscar por nombre, ciudad…">
            </div>
        </div>

        <!-- Vista tarjetas -->
        <div class="row g-4 mb-5" id="listado-autores-tarjetas">
            <?php foreach ($autores as $autor): ?>

            <?php
            // Iniciales del avatar
            $inicial = mb_strtoupper(mb_substr(trim($autor['nombre']), 0, 1));
            ?>

            <div class="col-sm-6 col-xl-4"
                 data-fila-autor="<?= htmlspecialchars(
                     $autor['nombre']   . ' ' .
                     $autor['apellido'] . ' ' .
                     $autor['ciudad']   . ' ' .
                     $autor['pais']
                 ) ?>">
                <div class="autor-card">
                    <!-- Avatar con inicial -->
                    <div class="autor-avatar"><?= $inicial ?></div>

                    <!-- Datos -->
                    <div class="flex-grow-1">
                        <h3 class="autor-nombre">
                            <?= htmlspecialchars(trim($autor['nombre'])) ?>
                            <?= htmlspecialchars(trim($autor['apellido'])) ?>
                        </h3>

                        <p class="autor-info">
                            <i class="bi bi-geo-alt"></i>
                            <?= htmlspecialchars($autor['ciudad']) ?>,
                            <?= htmlspecialchars($autor['estado']) ?> &mdash;
                            <?= htmlspecialchars($autor['pais']) ?>
                        </p>

                        <p class="autor-info">
                            <i class="bi bi-telephone"></i>
                            <?= htmlspecialchars($autor['telefono']) ?>
                        </p>

                        <p class="autor-info">
                            <i class="bi bi-mailbox"></i>
                            CP: <?= htmlspecialchars($autor['cod_postal']) ?>
                        </p>

                        <div class="mt-2">
                            <span class="badge-tipo">
                                <i class="bi bi-journals me-1"></i>
                                <?= $autor['total_libros'] ?> libro(s)
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <?php endforeach; ?>
        </div>

        <!-- Tabla resumida -->
        <h2 class="seccion-titulo mt-5">Tabla Resumen de Autores</h2>
        <hr class="seccion-linea">

        <div class="table-responsive">
            <table class="table tabla-libreria">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Apellido</th>
                        <th>Nombre</th>
                        <th>Teléfono</th>
                        <th>Ciudad</th>
                        <th>Estado</th>
                        <th>País</th>
                        <th>Libros</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($autores as $autor): ?>
                    <tr>
                        <td>
                            <code style="color:var(--color-acento);font-size:.75rem;">
                                <?= htmlspecialchars($autor['id_autor']) ?>
                            </code>
                        </td>
                        <td style="color:var(--color-blanco);font-family:var(--fuente-display);">
                            <?= htmlspecialchars(trim($autor['apellido'])) ?>
                        </td>
                        <td><?= htmlspecialchars(trim($autor['nombre'])) ?></td>
                        <td style="color:var(--color-texto-suave);font-size:.82rem;">
                            <?= htmlspecialchars($autor['telefono']) ?>
                        </td>
                        <td><?= htmlspecialchars($autor['ciudad']) ?></td>
                        <td><?= htmlspecialchars($autor['estado']) ?></td>
                        <td>
                            <span class="badge-tipo"><?= htmlspecialchars($autor['pais']) ?></span>
                        </td>
                        <td>
                            <strong style="color:var(--color-acento);"><?= $autor['total_libros'] ?></strong>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Estadísticas -->
        <div class="row g-3 mt-4">
            <div class="col-6 col-md-4">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-people"></i>
                    </div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);"><?= $total_autores ?></div>
                    <small style="color:var(--color-texto-suave);">Total Autores</small>
                </div>
            </div>

            <?php
            $paises = count(array_unique(array_column($autores, 'pais')));
            $ciudades = count(array_unique(array_column($autores, 'ciudad')));
            ?>

            <div class="col-6 col-md-4">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-globe-americas"></i>
                    </div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);"><?= $paises ?></div>
                    <small style="color:var(--color-texto-suave);">País(es)</small>
                </div>
            </div>

            <div class="col-6 col-md-4">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-buildings"></i>
                    </div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);"><?= $ciudades ?></div>
                    <small style="color:var(--color-texto-suave);">Ciudades</small>
                </div>
            </div>
        </div>

    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
