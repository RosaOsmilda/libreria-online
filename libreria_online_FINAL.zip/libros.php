<?php
$titulo_pagina = 'Libros';
require_once 'includes/conexion.php';
require_once 'includes/header.php';

$pdo = conectar();

// Obtener todos los libros con sus autores (JOIN)
$stmt = $pdo->query(
    "SELECT t.id_titulo,
            t.titulo,
            t.tipo,
            t.precio,
            t.avance,
            t.total_ventas,
            t.notas,
            t.fecha_pub,
            t.id_pub,
            GROUP_CONCAT(CONCAT(a.nombre, ' ', a.apellido) SEPARATOR ' / ') AS autores
     FROM titulos t
     LEFT JOIN titulo_autor ta ON t.id_titulo = ta.id_titulo
     LEFT JOIN autores a        ON ta.id_autor  = a.id_autor
     GROUP BY t.id_titulo
     ORDER BY t.titulo ASC"
);

$libros       = $stmt->fetchAll();
$total_libros = count($libros);
?>

<!-- ===== CABECERA DE PÁGINA ===== -->
<section class="hero" style="padding:60px 0 50px;">
    <div class="container position-relative">
        <span class="hero-pretitle">Catálogo completo</span>
        <h1 class="hero-title" style="font-size:clamp(2rem,4vw,3rem);">
            <i class="bi bi-journals me-2 text-accent"></i>Libros Disponibles
        </h1>
        <p class="hero-subtitle">
            Explora nuestra colección de <?= $total_libros ?> títulos en múltiples categorías.
        </p>
    </div>
</section>

<!-- ===== LISTADO DE LIBROS ===== -->
<section class="seccion">
    <div class="container">

        <!-- Barra de búsqueda + contador -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center mb-4 gap-3">

            <div class="contador-resultados">
                <i class="bi bi-list-ul"></i>
                <span id="contador-libros"><?= $total_libros ?> libro(s) encontrado(s)</span>
            </div>

            <div class="buscador-wrap">
                <i class="bi bi-search"></i>
                <input type="text"
                       id="buscar-libro"
                       class="form-control"
                       placeholder="Buscar título, autor, categoría…">
            </div>
        </div>

        <!-- Tabla de libros -->
        <div class="table-responsive">
            <table class="table tabla-libreria align-middle">
                <thead>
                    <tr>
                        <th><i class="bi bi-hash me-1"></i>ID</th>
                        <th><i class="bi bi-book me-1"></i>Título</th>
                        <th><i class="bi bi-person me-1"></i>Autor(es)</th>
                        <th><i class="bi bi-tag me-1"></i>Categoría</th>
                        <th><i class="bi bi-currency-dollar me-1"></i>Precio</th>
                        <th><i class="bi bi-bar-chart me-1"></i>Ventas</th>
                        <th><i class="bi bi-calendar me-1"></i>Publicación</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($libros as $libro): ?>
                    <tr data-fila-libro="<?= htmlspecialchars(
                        $libro['titulo'] . ' ' .
                        ($libro['autores'] ?? '') . ' ' .
                        $libro['tipo']
                    ) ?>">
                        <td>
                            <code style="color:var(--color-acento);font-size:.78rem;">
                                <?= htmlspecialchars($libro['id_titulo']) ?>
                            </code>
                        </td>

                        <td>
                            <span style="color:var(--color-blanco);font-family:var(--fuente-display);font-size:.9rem;">
                                <?= htmlspecialchars($libro['titulo']) ?>
                            </span>
                            <?php if ($libro['notas']): ?>
                            <br>
                            <small style="color:var(--color-texto-suave);font-size:.72rem;line-height:1.3;display:block;max-width:320px;margin-top:.2rem;">
                                <?= htmlspecialchars(mb_strimwidth($libro['notas'], 0, 90, '…')) ?>
                            </small>
                            <?php endif; ?>
                        </td>

                        <td style="color:var(--color-texto-suave);font-size:.82rem;">
                            <?= $libro['autores'] ? htmlspecialchars($libro['autores']) : '<em>Sin autor registrado</em>' ?>
                        </td>

                        <td>
                            <span class="badge-tipo"><?= htmlspecialchars($libro['tipo']) ?></span>
                        </td>

                        <td style="white-space:nowrap;">
                            <?php if ($libro['precio']): ?>
                                <strong style="color:var(--color-acento);">$<?= number_format($libro['precio'], 2) ?></strong>
                            <?php else: ?>
                                <span style="color:var(--color-texto-suave);font-size:.8rem;">N/D</span>
                            <?php endif; ?>
                        </td>

                        <td style="color:var(--color-texto-suave);font-size:.82rem;white-space:nowrap;">
                            <?php if ($libro['total_ventas']): ?>
                                <i class="bi bi-arrow-up-short text-success"></i>
                                <?= number_format($libro['total_ventas']) ?>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>

                        <td style="color:var(--color-texto-suave);font-size:.8rem;white-space:nowrap;">
                            <?= date('d/m/Y', strtotime($libro['fecha_pub'])) ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div><!-- /table-responsive -->

        <!-- Resumen estadístico -->
        <?php
        $con_precio = array_filter($libros, fn($l) => $l['precio'] > 0);
        $precio_promedio = count($con_precio) > 0
            ? array_sum(array_column(iterator_to_array((function() use ($con_precio) { yield from $con_precio; })()), 'precio')) / count($con_precio)
            : 0;

        // Recalcular con array functions simples
        $suma = 0; $cnt = 0;
        foreach ($libros as $l) { if ($l['precio'] > 0) { $suma += $l['precio']; $cnt++; } }
        $precio_promedio = $cnt > 0 ? $suma / $cnt : 0;

        $total_ventas_global = array_sum(array_column($libros, 'total_ventas'));
        ?>

        <div class="row g-3 mt-4">
            <div class="col-6 col-md-3">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-journals"></i>
                    </div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);"><?= $total_libros ?></div>
                    <small style="color:var(--color-texto-suave);">Total Títulos</small>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-currency-dollar"></i>
                    </div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);">$<?= number_format($precio_promedio, 2) ?></div>
                    <small style="color:var(--color-texto-suave);">Precio Promedio</small>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-bar-chart"></i>
                    </div>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);"><?= number_format($total_ventas_global) ?></div>
                    <small style="color:var(--color-texto-suave);">Ventas Totales</small>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="libro-card text-center py-3">
                    <div style="font-size:1.8rem;color:var(--color-acento);margin-bottom:.5rem;">
                        <i class="bi bi-bookmark-star"></i>
                    </div>
                    <?php $tipos = count(array_unique(array_column($libros, 'tipo'))); ?>
                    <div style="font-size:1.5rem;font-weight:700;color:var(--color-blanco);"><?= $tipos ?></div>
                    <small style="color:var(--color-texto-suave);">Categorías</small>
                </div>
            </div>
        </div>

    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
