<?php
// Configuración de la base de datos
define('DB_HOST', 'sql106.infinityfree.com');
define('DB_NAME', 'if0_41614884_dblibreria');
define('DB_USER', 'if0_41614884');
define('DB_PASS', 'fbrgP2RjbORc8v');
define('DB_CHARSET', 'utf8');

/**
 * Función que retorna una conexión PDO a la base de datos
 */
function conectar() {
    static $pdo = null;

    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $opciones = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $opciones);
        } catch (PDOException $e) {
            die('<div style="background:#fee;border:1px solid #c00;padding:20px;margin:20px;border-radius:8px;font-family:sans-serif;">
                    <strong>Error de conexión a la base de datos:</strong><br>
                    ' . htmlspecialchars($e->getMessage()) . '
                 </div>');
        }
    }

    return $pdo;
}
?>
