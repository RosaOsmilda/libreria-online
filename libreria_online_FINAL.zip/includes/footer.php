
<!-- ===== PIE DE PÁGINA ===== -->
<footer class="footer mt-auto py-5">
    <div class="container">
        <div class="row gy-4">
            <!-- Columna: Marca -->
            <div class="col-md-4">
                <h5 class="footer-brand mb-3">
                    <i class="bi bi-book-half me-2"></i>Librería <em>Online</em>
                </h5>
                <p class="text-muted small">
                    Tu catálogo digital de libros y autores. Descubre miles de títulos disponibles
                    en nuestra colección curada.
                </p>
            </div>

            <!-- Columna: Enlaces rápidos -->
            <div class="col-md-4">
                <h6 class="footer-heading mb-3">Explorar</h6>
                <ul class="list-unstyled footer-links">
                    <li><a href="index.php"><i class="bi bi-chevron-right me-1"></i>Inicio</a></li>
                    <li><a href="libros.php"><i class="bi bi-chevron-right me-1"></i>Catálogo de Libros</a></li>
                    <li><a href="autores.php"><i class="bi bi-chevron-right me-1"></i>Nuestros Autores</a></li>
                    <li><a href="contacto.php"><i class="bi bi-chevron-right me-1"></i>Contacto</a></li>
                </ul>
            </div>

            <!-- Columna: Contacto -->
            <div class="col-md-4">
                <h6 class="footer-heading mb-3">Contacto</h6>
                <ul class="list-unstyled text-muted small">
                    <li class="mb-2"><i class="bi bi-envelope me-2 text-accent"></i>info@libreriaonline.com</li>
                    <li class="mb-2"><i class="bi bi-telephone me-2 text-accent"></i>+1 (809) 000-0000</li>
                    <li><i class="bi bi-geo-alt me-2 text-accent"></i>Santo Domingo, RD</li>
                </ul>
            </div>
        </div>

        <hr class="footer-divider my-4">

        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center">
            <p class="text-muted small mb-2 mb-md-0">
                &copy; <?= date('Y') ?> Librería Online &mdash; Proyecto Final &bull; Programación Web
            </p>
            <p class="text-muted small mb-0">
                Desarrollado con <i class="bi bi-heart-fill text-danger"></i> usando PHP &amp; MySQL
            </p>
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- Script personalizado -->
<script src="js/app.js"></script>
</body>
</html>
