<?php
// Determinar la página activa para el menú
$pagina_actual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($titulo_pagina) ? htmlspecialchars($titulo_pagina) . ' — ' : '' ?>Librería Online</title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=Lato:wght@300;400;700&display=swap" rel="stylesheet">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- Estilos personalizados -->
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<!-- ===== BARRA DE NAVEGACIÓN ===== -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top" id="navbar-principal">
    <div class="container">
        <!-- Logo / Marca -->
        <a class="navbar-brand d-flex align-items-center gap-2" href="index.php">
            <i class="bi bi-book-half fs-4"></i>
            <span class="brand-text">Librería <em>Online</em></span>
        </a>

        <!-- Botón hamburguesa -->
        <button class="navbar-toggler" type="button"
                data-bs-toggle="collapse" data-bs-target="#menuNavegacion"
                aria-controls="menuNavegacion" aria-expanded="false"
                aria-label="Alternar navegación">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Menú -->
        <div class="collapse navbar-collapse" id="menuNavegacion">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item">
                    <a class="nav-link <?= $pagina_actual === 'index.php' ? 'active' : '' ?>" href="index.php">
                        <i class="bi bi-house me-1"></i>Inicio
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $pagina_actual === 'libros.php' ? 'active' : '' ?>" href="libros.php">
                        <i class="bi bi-journals me-1"></i>Libros
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $pagina_actual === 'autores.php' ? 'active' : '' ?>" href="autores.php">
                        <i class="bi bi-people me-1"></i>Autores
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $pagina_actual === 'contacto.php' ? 'active' : '' ?>" href="contacto.php">
                        <i class="bi bi-envelope me-1"></i>Contacto
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>
