# 📚 Librería Online — Proyecto Final
**Programación Web · Daniel Parra**

---

## 📋 Descripción
Portal web que permite consultar el catálogo de libros y autores de una librería online.
Desarrollado con **PHP + MySQL + Bootstrap 5**, usando **PDO** para todas las consultas.

---

## 🗂️ Estructura del proyecto
```
libreria/
├── index.php               ← Página de inicio (hero + últimos libros + categorías)
├── libros.php              ← Listado completo de libros (con buscador)
├── autores.php             ← Listado de autores (tarjetas + tabla)
├── contacto.php            ← Formulario de contacto (POST → BD)
├── crear_tabla_contacto.sql← SQL de la tabla contacto (referencia)
├── includes/
│   ├── conexion.php        ← Conexión PDO a MySQL
│   ├── header.php          ← Navbar + <head> HTML
│   └── footer.php          ← Footer + scripts JS
├── css/
│   └── estilos.css         ← Estilos personalizados (tema oscuro dorado)
└── js/
    └── app.js              ← JavaScript: buscador, validación, animaciones
```

---

## ⚙️ Instalación

### 1. Base de datos
```sql
-- En phpMyAdmin o MySQL CLI:
CREATE DATABASE dblibreria CHARACTER SET utf8 COLLATE utf8_general_ci;
USE dblibreria;

-- Importar el archivo proporcionado:
SOURCE Base_Datos_Libreria.sql;

-- La tabla 'contacto' se crea automáticamente al primer envío de formulario,
-- o puedes ejecutar manualmente:
SOURCE crear_tabla_contacto.sql;
```

### 2. Configurar conexión
Editar `includes/conexion.php`:
```php
define('DB_HOST', 'localhost');   // Host de MySQL
define('DB_NAME', 'dblibreria'); // Nombre de la base de datos
define('DB_USER', 'root');       // Usuario MySQL
define('DB_PASS', '');           // Contraseña MySQL
```

### 3. Servidor web
- **XAMPP / WAMP / Laragon**: Copia la carpeta `libreria/` dentro de `htdocs/` o `www/`
- Accede en: `http://localhost/libreria/`
- **Servidor remoto**: Sube los archivos vía FTP, configura las credenciales de BD

---

## ✅ Requerimientos cubiertos

| # | Requerimiento | Estado |
|---|---------------|--------|
| 1 | Importar base de datos "Librería" | ✅ Incluido SQL |
| 2 | Crear aplicación web | ✅ Completo |
| 3 | Usar plantilla Bootstrap | ✅ Bootstrap 5 |
| 4 | Portal en español | ✅ Todo en español |
| 5 | Página listado de libros | ✅ `libros.php` |
| 6 | Página listado de autores | ✅ `autores.php` |
| 7 | Página formulario de contacto | ✅ `contacto.php` |
| 8 | Tabla `contacto` con campos requeridos | ✅ Auto-creada |
| 9 | Datos del formulario guardados en BD | ✅ PDO INSERT |
| 10 | Todas las conexiones/consultas con PDO | ✅ PDO en todo |
| 11 | CSS y JavaScript aplicados | ✅ Estilos + buscador JS |

---

## 🛠️ Tecnologías utilizadas
- **PHP 7.4+** — Backend y lógica de servidor
- **MySQL** — Base de datos relacional
- **PDO** — Conexión y consultas preparadas
- **HTML5 / CSS3** — Estructura y estilos
- **Bootstrap 5.3** — Framework CSS responsive
- **Bootstrap Icons** — Iconografía
- **JavaScript (Vanilla)** — Buscador dinámico, validación, animaciones
- **Google Fonts** — Playfair Display + Lato

---

## 📄 Páginas del portal

### `index.php` — Inicio
- Hero con estadísticas dinámicas (total libros, autores, categorías)
- Últimas 6 incorporaciones con JOIN entre `titulos` y `autores`
- Grid de categorías disponibles

### `libros.php` — Catálogo de Libros
- Tabla completa con JOIN: `titulos` ↔ `titulo_autor` ↔ `autores`
- Buscador en tiempo real (JavaScript)
- Contador de resultados dinámico
- Estadísticas: precio promedio, ventas totales

### `autores.php` — Autores
- Tarjetas con avatar generado por inicial del nombre
- Datos: nombre, ciudad, estado, país, teléfono, total libros
- Tabla resumen al final
- Buscador en tiempo real

### `contacto.php` — Contacto
- Formulario con validación PHP (servidor) + JavaScript (cliente)
- Campos: nombre, correo, asunto, comentario
- Almacenamiento en tabla `contacto` usando PDO prepared statements
- Mensajes de éxito / error con auto-ocultamiento

---

## 🔑 Conceptos PHP utilizados
- `PDO` y `PDO::prepare()` / `execute()`
- `foreach` para recorrer resultados
- `COUNT()` de MySQL para estadísticas
- `sizeof()` / `count()` en arrays PHP
- Método `GET` (buscador URL) y `POST` (formulario)
- `GROUP_CONCAT()` para agrupar autores por libro
- Validación con `filter_var(FILTER_VALIDATE_EMAIL)`
- `htmlspecialchars()` para prevenir XSS
